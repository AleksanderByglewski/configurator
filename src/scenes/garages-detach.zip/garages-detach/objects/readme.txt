The base and the base template are responsible for the general structure of the objects
Base is to serve as distro for classes 
Base_template is used to create new objects